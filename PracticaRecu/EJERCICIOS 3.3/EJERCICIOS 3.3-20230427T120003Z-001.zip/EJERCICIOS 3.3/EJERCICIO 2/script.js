function CambiarImagen(imagen) {
 document.getElementById(imagen).setAttribute('src','pez.jpeg');
}

function CambiarImagen2(imagen) {
 document.getElementById(imagen).setAttribute('src','oso.jpg');
}